import * as THREE from 'three';
import {createLogo} from './logo.js';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
export const ARCH_SPEC={width:9,heightAboveSupport:4,heightAboveDancefloor:5,supportAboveDancefloor:1,dancefloorY:.1,supportY:1.1,crownY:5.1,widthReference:'outer structural envelope',heightReference:'crown of truss; fixtures and sign separate',source:'User supplied dimensions'};
export function createArch(position){const root=new THREE.Group();root.name='GLITZ_ARCH_9M';root.position.copy(position);root.position.y=ARCH_SPEC.supportY;root.userData={...ARCH_SPEC};
const truss=new THREE.Group(),equipment=new THREE.Group(),sign=new THREE.Group();truss.name='ARCH_TRUSS';equipment.name='ARCH_LIGHTS_AUDIO';sign.name='ARCH_GLITZ_LETTERS';root.add(truss,equipment,sign);
const silver=new THREE.MeshStandardMaterial({color:'#bdc4c5',metalness:.8,roughness:.3}),black=new THREE.MeshStandardMaterial({color:'#20252a',roughness:.65}),white=new THREE.MeshStandardMaterial({color:'#f4f1e7',roughness:.5});
function box(g,name,x,y,z,w,h,d,m){const o=new THREE.Mesh(new RoundedBoxGeometry(w,h,d,2,Math.min(.025,w/8)),m);o.position.set(x,y,z);o.name=name;g.add(o);return o}
function tube(g,name,a,b,r=.024,m=silver){const d=b.clone().sub(a),o=new THREE.Mesh(new THREE.CylinderGeometry(r,r,d.length(),8),m);o.position.copy(a).add(b).multiplyScalar(.5);o.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());o.name=name;g.add(o);return o}
const point=(a,inner=false,z=0)=>new THREE.Vector3((inner?4.195:4.475)*Math.cos(a),.025+(inner?3.695:3.95)*Math.sin(a),z);
// Outer tube reaches exactly x +/-4.5 and y=4.0. Semi-ellipse, not a semicircle.
for(let i=0;i<48;i++){const a=i*Math.PI/48,b=(i+1)*Math.PI/48;for(const z of [-.16,.16]){tube(truss,'Corrente esterno',point(a,false,z),point(b,false,z));tube(truss,'Corrente interno',point(a,true,z),point(b,true,z));tube(truss,'Diagonale faccia',point(a,i%2===0,z),point(b,i%2!==0,z),.010);if(i%2===0)tube(truss,'Montante radiale',point(a,false,z),point(a,true,z),.012)}tube(truss,'Diagonale profondita',point(a,false,-.16),point(b,false,.16),.01);if(i%4===0)for(const inner of [false,true])tube(truss,'Traverso',point(a,inner,-.16),point(a,inner,.16),.014)}
for(const x of [-4.475,4.475])box(equipment,'Piastra piede',x,-.025,0,.43,.05,.47,silver);
// Individual 40–50 cm LED segments, with black housings.
for(let i=0;i<24;i++){const a=.16+i*(Math.PI-.32)/24,b=a+(Math.PI-.32)/24*.91;if(Math.abs(4.475*Math.cos((a+b)/2))<1.12)continue;const pa=point(a,false,.202),pb=point(b,false,.202);tube(equipment,'Barra LED scocca',pa,pb,.039,black);const c=new THREE.Color().setHSL(.66+i/24*.07,.9,.66);const led=new THREE.MeshStandardMaterial({color:c,emissive:c,emissiveIntensity:.65});tube(equipment,'Barra LED diffusore',pa.clone().add(new THREE.Vector3(0,0,.022)),pb.clone().add(new THREE.Vector3(0,0,.022)),.017,led)}
for(const a of [.25,.58,.91,1.22,1.91,2.24,2.57,2.89]){const p=point(a,false,0);const g=new THREE.Group();g.position.copy(p);g.rotation.z=a-Math.PI/2;equipment.add(g);box(g,'Testa mobile base',0,.045,0,.26,.085,.29,black);for(const x of [-.14,.14])box(g,'Forcella testa mobile',x,.22,0,.04,.3,.08,black);const h=box(g,'Testa mobile proiettore',0,.29,.02,.24,.32,.23,black);h.rotation.x=-.38;const lens=new THREE.Mesh(new THREE.CylinderGeometry(.074,.074,.014,20),new THREE.MeshStandardMaterial({color:'#99a6ba',metalness:.2,roughness:.22}));lens.rotation.x=Math.PI/2-.38;lens.position.set(0,.29,.155);lens.name='Lente testa mobile';g.add(lens)}
for(const x of [-3.13,3.13]){const y=.025+3.95*Math.sqrt(1-(x/4.475)**2);tube(equipment,'Sospensione audio',new THREE.Vector3(x,y-.1,-.07),new THREE.Vector3(x,y-.65,-.07),.014,black);for(let i=0;i<2;i++){const o=box(equipment,'Line array modulo',x,y-.67-i*.32,.01,.70,.29,.42,black);o.rotation.x=.035+i*.045;box(equipment,'Griglia diffusore',x,y-.67-i*.32,.228,.65,.25,.015,new THREE.MeshStandardMaterial({color:'#333941',roughness:1}));}}

// Rear portal, rounded upper corners and central spine visible in DSC09488 / DSC09650.
const rear=new THREE.Group();rear.name='REAR_SCREEN_TRUSS';root.add(rear);
function beam(a,b,w=.30){const d=b.clone().sub(a).normalize();const ref=Math.abs(d.y)>.9?new THREE.Vector3(1,0,0):new THREE.Vector3(0,1,0);const u=new THREE.Vector3().crossVectors(d,ref).normalize().multiplyScalar(w/2),v=new THREE.Vector3().crossVectors(d,u).normalize().multiplyScalar(w/2);const corners=[u.clone().add(v),u.clone().sub(v),u.clone().negate().sub(v),v.clone().sub(u)];for(const c of corners)tube(rear,'Corrente truss rettilinea',a.clone().add(c),b.clone().add(c),.024);const n=Math.ceil(a.distanceTo(b)/.34);for(let i=0;i<n;i++)for(let k=0;k<4;k++){const aa=a.clone().lerp(b,i/n),bb=a.clone().lerp(b,(i+1)/n);tube(rear,'Diagonale truss rettilinea',aa.clone().add(corners[k]),bb.clone().add(corners[(k+1)%4]),.009);if(i%3===0)tube(rear,'Traverso truss',aa.clone().add(corners[k]),aa.clone().add(corners[(k+1)%4]),.012)}}
const rz=-5.79,top=3.7;
for(const side of [-1,1]){beam(new THREE.Vector3(side*2.95,-.5,rz),new THREE.Vector3(side*2.95,top-.42,rz));for(let i=0;i<8;i++){const a=i*Math.PI/16,b=(i+1)*Math.PI/16;beam(new THREE.Vector3(side*(2.53+.42*Math.cos(a)),top-.42+.42*Math.sin(a),rz),new THREE.Vector3(side*(2.53+.42*Math.cos(b)),top-.42+.42*Math.sin(b),rz));}}
beam(new THREE.Vector3(-2.53,top,rz),new THREE.Vector3(2.53,top,rz));
beam(new THREE.Vector3(0,3.81,-.16),new THREE.Vector3(0,top,rz));
// Flanges and couplers at modular arch joints.
for(let i=1;i<8;i++){const a=i*Math.PI/8;for(const z of [-.16,.16]){tube(equipment,'Giunto modulo arco',point(a,false,z).add(new THREE.Vector3(0,-.045,0)),point(a,false,z).add(new THREE.Vector3(0,.045,0)),.034,silver);}}

// Original brand silhouette on the exterior LED side, with clear LED space.
const originalLogo=createLogo(1.85);originalLogo.position.set(0,3.80,.29);sign.add(originalLogo);
root.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;o.userData.archComponent=true}});return {root,truss,equipment,sign,rear,spec:ARCH_SPEC};}
